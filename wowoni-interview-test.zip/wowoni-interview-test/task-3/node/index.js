"use strict";
/**
 * Guessing that the text pattern within file is fixed at 3 words per line,
 * which includes person, action and object.
 * In output, person has to be wild card and action with object has to be unique.
 */
require("fs").readFile("sample.txt", "utf-8", (err, data) => {
    console.log(
        [
            ...new Set(
                data
                    .split("\r\n")
                    .map((ele) => `" * ${ele.replace(/^\S* /, "")} "`)
            ),
        ].join("\r\n")
    );
});
