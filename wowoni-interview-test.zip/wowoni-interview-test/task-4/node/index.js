"use strict";
let arr1 = [1,2,3,4]
let arr2 = [...arr1]; // Method 1
// let arr2 = Object.values(arr1); // Method 2
// let arr2 = arr1.map(ele => ele); // Method 3
arr1.push(5);
console.log("arr1: ", arr1);
console.log("arr2: ", arr2);