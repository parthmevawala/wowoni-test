"use strict";

const { Router } = require("express");
const { readFileSync, writeFileSync } = require("fs");

let countryRoutes = new Router();

// Following api will fetch a single country with code provided.
countryRoutes.get("/countries/country-code", async (req, res, next) => {
    try {
        const fileJson = await JSON.parse(
            readFileSync(__dirname + "/files/countries.json", "utf-8")
        );
        const code = req.query.code;
        res.send(
            !code
                ? "Invalid API request. Please input code within querystring."
                : fileJson.find((cnt) => cnt.code === code) ||
                      "Country does not exist."
        );
    } catch (error) {
        res.send(error);
    }
});

// Following api will add a new country if all the parameters are provided.
countryRoutes.get("/add/country", async (req, res, next) => {
    let message = undefined;
    if (!req.query.id) message = "Country id is missing in request.";
    if (!req.query.name) message = "Country name is missing in request.";
    if (!req.query.code) message = "Country code is missing in request.";

    if (message) {
        // api error
        return res.send(message);
    } else {
        let fileJson = [];
        try {
            fileJson = await JSON.parse(
                readFileSync(__dirname + "/files/countries.json", "utf-8")
            );
        } catch (error) {}

        message = undefined;

        const query = {
            name: req.query.name,
            code: req.query.code,
            id: parseInt(req.query.id),
        };

        const index = fileJson.findIndex(
            (cnt) =>
                cnt.id === query.id ||
                cnt.name === query.name ||
                cnt.code === query.code
        );

        if (index === -1) {
            fileJson.push({ ...query });
            message = "New country has been added.";
        } else {
            fileJson[index] = { ...query };
            message = "Existing country has been replaced";
        }

        try {
            writeFileSync(
                __dirname + "/files/countries.json",
                JSON.stringify(fileJson),
                "utf-8"
            );
        } catch (error) {
            res.send({
                data: fileJson[index === -1 ? fileJson.length - 1 : index],
                message,
            });
        }

        res.send({
            data: fileJson[index === -1 ? fileJson.length - 1 : index],
            message,
        });
    }
});

// Listing all countries in tabular form.
countryRoutes.get("/countries", async (req, res, next) => {
    try {
        const fileJson = await JSON.parse(
            readFileSync(__dirname + "/files/countries.json", "utf-8")
        );
        res.send(JSON.stringify(fileJson));
    } catch (error) {
        res.send(error);
    }
});

module.exports = countryRoutes;
