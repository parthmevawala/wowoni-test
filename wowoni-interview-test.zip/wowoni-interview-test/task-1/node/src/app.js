"use strict";

const http = require("http");
const cors = require("cors");
const express = require("express");
const app = express();
const server = http.createServer(app);
const routes = require("./routes");

// Basic requirements
app.use(cors(), express.json(), express.urlencoded({ extended: true }), routes);

server.listen(3001, () => {
    console.log("Server is listening to 3001 port.");
});
