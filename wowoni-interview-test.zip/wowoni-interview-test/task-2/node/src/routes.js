"use strict";

const { Router } = require("express");
const jwt = require("jsonwebtoken");

let router = new Router();

// Generating token
router.get("/generateToken", (req, res, next) =>
    res.send({
        data: jwt.sign({ object: "value" }, "secret", { expiresIn: "5m" }),
        message: "Token generated.",
    })
);

// Verifying token
router.put("/verifyToken", (req, res, next) => {
    try {
        if (!req.body.token) throw new Error("Invalid request.");
        jwt.verify(req.body.token, "secret");
        res.send("Token verified.");
    } catch (error) {
        res.send(error.message);
    }
});

module.exports = router;
